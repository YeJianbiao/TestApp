﻿// Copyright (c) Brock Allen & Dominick Baier. All rights reserved.
// Licensed under the Apache License, Version 2.0. See LICENSE in the project root for license information.

using IdentityServer4.Models;
using IdentityServer4.Services.InMemory;
using System.Collections.Generic;
using System.Security.Claims;

namespace OAuth2Comm
{
    public class Config
    {
        // scopes define the resources in your system
        public static IEnumerable<Scope> GetScopes()
        {
            return new List<Scope>
            {
                //StandardScopes.OpenId,
                //StandardScopes.Profile,
                StandardScopes.OfflineAccess,

                new Scope
                {
                    Name = "api1",
                    DisplayName = "API1 access",
                    Description = "My API"
                }
            };
        }

        // clients want to access resources (aka scopes)
        public static IEnumerable<Client> GetClients()
        {
            // client credentials client
            return new List<Client>
            {
                new Client
                {
                    ClientId = "auth_clientid",
                    ClientName = "AuthorizationCode Clientid",
                    AllowedGrantTypes = new string[] { GrantType.AuthorizationCode },

                    ClientSecrets = 
                    {
                        new Secret("secret".Sha256())
                    },

                    RedirectUris = { "http://localhost:38500/" },
                    PostLogoutRedirectUris = { "http://localhost:38500/" },

                    AuthorizationCodeLifetime = 600,

                    AllowedScopes = 
                    {
                        //StandardScopes.OpenId.Name,
                        //StandardScopes.Profile.Name,
                        StandardScopes.OfflineAccess.Name,
                        "api1"
                    }
                }
            };
        }

        public static List<InMemoryUser> GetUsers()
        {
            return new List<InMemoryUser>
            {
                new InMemoryUser
                {
                    Subject = "1",
                    Username = "admin",
                    Password = "123",
                    Claims = new List<Claim>
                    {
                        new Claim("name", "Admin"),
                        new Claim("website", "https://admin.com")
                    }
                }
            };
        }
    }
}