﻿// Copyright (c) Brock Allen & Dominick Baier. All rights reserved.
// Licensed under the Apache License, Version 2.0. See LICENSE in the project root for license information.


using IdentityServer4.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Linq;
using System.Threading.Tasks;
using IdentityServer4.Models;
using IdentityServer4.Stores;
using IdentityServer4.Quickstart.UI.Models;

namespace OAuth2AuthorizationCode.Controllers
{
    /// <summary>
    /// This controller implements the consent logic
    /// </summary>
    public class ConsentController : Controller
    {
        private readonly ILogger<ConsentController> _logger;
        private readonly IClientStore _clientStore;
        private readonly IScopeStore _scopeStore;
        private readonly IIdentityServerInteractionService _interaction;
        
        public ConsentController(
            ILogger<ConsentController> logger,
            IIdentityServerInteractionService interaction,
            IClientStore clientStore,
            IScopeStore scopeStore)
        {
            _logger = logger;
            _interaction = interaction;
            _clientStore = clientStore;
            _scopeStore = scopeStore;
        }

        /// <summary>
        /// 显示用户可授予的权限
        /// </summary>
        /// <param name="returnUrl"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> Index(string returnUrl)
        {
            var vm = await BuildViewModelAsync(returnUrl);
            if (vm != null)
            {
                return View("Index", vm);
            }

            return View("Error", new ErrorViewModel
            {
                Error = new ErrorMessage { Error = "Invalid Request" },
            });
        }

        /// <summary>
        /// 用户授权验证
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(ConsentInputModel model)
        {
            //解析returnUrl
            var request = await _interaction.GetAuthorizationContextAsync(model.ReturnUrl);
            if (request != null && model != null)
            {
                if (ModelState.IsValid)
                {
                    ConsentResponse response = null;
                    //用户不同意授权
                    if (model.Button == "no")
                    {
                        response = ConsentResponse.Denied;
                    }
                    //用户同意授权
                    else if (model.Button == "yes")
                    {
                        //设置已选择授权的Scopes
                        if (model.ScopesConsented != null && model.ScopesConsented.Any())
                        {
                            response = new ConsentResponse
                            {
                                RememberConsent = model.RememberConsent,
                                ScopesConsented = model.ScopesConsented
                            };
                        }
                        else
                        {
                            ModelState.AddModelError("", "You must pick at least one permission.");
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", "Invalid Selection");
                    }

                    if (response != null)
                    {
                        //将授权的结果设置到identityserver中
                        await _interaction.GrantConsentAsync(request, response);
                        //授权成功重定向
                        return Redirect(model.ReturnUrl);
                    }
                }

                //有错误，重新授权
                var vm = await BuildViewModelAsync(model.ReturnUrl, model);
                if (vm != null)
                {
                    return View(vm);
                }
            }

            return View("Error", new ErrorViewModel
            {
                Error = new ErrorMessage { Error = "Invalid Request" },
            });
        }

        /// <summary>
        /// 生成ViewModel
        /// </summary>
        /// <param name="returnUrl"></param>
        /// <param name="model"></param>
        /// <returns></returns>
        async Task<ConsentViewModel> BuildViewModelAsync(string returnUrl, ConsentInputModel model = null)
        {
            //解析returnUrl
            var request = await _interaction.GetAuthorizationContextAsync(returnUrl);
            if (request != null)
            {
                //验证并获取Client
                var client = await _clientStore.FindEnabledClientByIdAsync(request.ClientId);
                if (client != null)
                {
                    //验证并获取Scopes
                    var scopes = await _scopeStore.FindEnabledScopesAsync(request.ScopesRequested);
                    if (scopes != null && scopes.Any())
                    {
                        return new ConsentViewModel(model, returnUrl, request, client, scopes);
                    }
                    else
                    {
                        _logger.LogError("No scopes matching: {0}", request.ScopesRequested.Aggregate((x, y) => x + ", " + y));
                    }
                }
                else
                {
                    _logger.LogError("Invalid client id: {0}", request.ClientId);
                }
            }
            else
            {
                _logger.LogError("No consent request matching request: {0}", returnUrl);
            }

            return null;
        }
    }
}