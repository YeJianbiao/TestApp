﻿// Copyright (c) Brock Allen & Dominick Baier. All rights reserved.
// Licensed under the Apache License, Version 2.0. See LICENSE in the project root for license information.


using IdentityModel;
using IdentityServer4.Quickstart.UI.Models;
using IdentityServer4.Services;
using IdentityServer4.Services.InMemory;
using Microsoft.AspNetCore.Http.Authentication;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using IdentityServer4.Models;
using IdentityServer4.Stores;
using IdentityServer4;

namespace OAuth2AuthorizationCode.Controllers
{
    /// <summary>
    /// This sample controller implements a typical login/logout/provision workflow for local and external accounts.
    /// The login service encapsulates the interactions with the user data store. This data store is in-memory only and cannot be used for production!
    /// The interaction service provides a way for the UI to communicate with identityserver for validation and context retrieval
    /// </summary>
    public class AccountController : Controller
    {
        private readonly IIdentityServerInteractionService _interaction;
        private readonly IClientStore _clientStore;

        public AccountController(
            IIdentityServerInteractionService interaction,
            IClientStore clientStore)
        {
            _interaction = interaction;
            _clientStore = clientStore;
        }

        /// <summary>
        /// 登陆页面
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> Login(string returnUrl)
        {
            var context = await _interaction.GetAuthorizationContextAsync(returnUrl);
            var vm = BuildLoginViewModel(returnUrl, context);
            return View(vm);
        }

        /// <summary>
        /// 登陆账号验证
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginInputModel model)
        {
            if (ModelState.IsValid)
            {
                //账号密码验证
                if (model.Username == "admin" && model.Password == "123456")
                {
                    AuthenticationProperties props = null;
                    //判断是否 记住登陆
                    if (model.RememberLogin)
                    {
                        props = new AuthenticationProperties
                        {
                            IsPersistent = true,
                            ExpiresUtc = DateTimeOffset.UtcNow.AddMonths(1)
                        };
                    };

                    //参数一：Subject，可在资源服务器中获取到，资源服务器通过User.Claims.Where(l => l.Type == "sub").FirstOrDefault();获取
                    //参数二：账号
                    await HttpContext.Authentication.SignInAsync("admin", "admin", props);

                    //验证ReturnUrl，ReturnUrl为重定向到授权页面
                    if (_interaction.IsValidReturnUrl(model.ReturnUrl))
                    {
                        return Redirect(model.ReturnUrl);
                    }

                    return Redirect("~/");
                }

                ModelState.AddModelError("", "Invalid username or password.");
            }

            //生成错误信息的LoginViewModel
            var vm = await BuildLoginViewModelAsync(model);
            return View(vm);
        }

        /// <summary>
        /// 生成LoginViewModel
        /// </summary>
        /// <param name="returnUrl"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        LoginViewModel BuildLoginViewModel(string returnUrl, AuthorizationRequest context)
        {
            return new LoginViewModel
            {
                //EnableLocalLogin = allowLocal,
                ReturnUrl = returnUrl,
                Username = context?.LoginHint,
            };
        }

        /// <summary>
        /// 账号验证失败的时候重新生成LoginViewModel
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        async Task<LoginViewModel> BuildLoginViewModelAsync(LoginInputModel model)
        {
            var context = await _interaction.GetAuthorizationContextAsync(model.ReturnUrl);
            var vm = BuildLoginViewModel(model.ReturnUrl, context);
            vm.Username = model.Username;
            vm.RememberLogin = model.RememberLogin;
            return vm;
        }

        /// <summary>
        /// 注销登陆页面(因为账号的一些相关信息会存储在cookie中的)
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> Logout(string logoutId)
        {
            if (User.Identity.IsAuthenticated == false)
            {
                //如果用户未并未授权过，那么返回
                return await Logout(new LogoutViewModel { LogoutId = logoutId });
            }
            //显示注销提示, 这可以防止攻击, 如果用户签署了另一个恶意网页
            var vm = new LogoutViewModel
            {
                LogoutId = logoutId
            };
            return View(vm);
        }

        /// <summary>
        /// 处理注销登陆
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout(LogoutViewModel model)
        {
            //清除Cookie中的授权信息
            await HttpContext.Authentication.SignOutAsync();

            //设置User使之呈现为匿名用户
            HttpContext.User = new ClaimsPrincipal(new ClaimsIdentity());

            Client logout = null;
            if (model != null && !string.IsNullOrEmpty(model.LogoutId))
            {
                //获取Logout的相关信息
                logout = await _clientStore.FindClientByIdAsync(model.LogoutId); 
            }

            var vm = new LoggedOutViewModel
            {
                PostLogoutRedirectUri = logout?.PostLogoutRedirectUris?.FirstOrDefault(),
                ClientName = logout?.ClientName,
            };

            return View("LoggedOut", vm);
        }
    }
}