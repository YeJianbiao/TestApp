﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ThirdPartyTest.Models;
using Common;
using Newtonsoft.Json;
using Microsoft.Extensions.Logging;

namespace ThirdPartyTest.Controllers
{
    public class HomeController : Controller
    {
        readonly ILogger<HomeController> _logger;
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Index(GrantClientViewModel model)
        {
            return View(model);
        }

        [HttpPost]
        public IActionResult Index(GrantClientInputModel model)
        {
            GrantClientViewModel vmodel = new GrantClientViewModel();
            if (ModelState.IsValid)
            {
                switch (model.CallType)
                {
                    case "AccessToken":
                        //访问授权服务器
                        return Redirect(OAuthConstants.AuthorizationServerBaseAddress + OAuthConstants.AuthorizePath + "?"
                            + "response_type=code"
                            + "&client_id=" + OAuthConstants.Clientid
                            + "&redirect_uri=" + OAuthConstants.AuthorizeCodeCallBackPath
                            + "&scope="  + OAuthConstants.Scopes                            
                            + "&state=" + OAuthConstants.State);
                        break;
                    case "RefreshToken":
                        {
                            //刷新AccessToken
                            var client = new HttpClientHepler(OAuthConstants.AuthorizationServerBaseAddress + OAuthConstants.TokenPath);
                            client.PostAsync(null,
                                "grant_type=" + "refresh_token" +
                                "&client_id=" + OAuthConstants.Clientid +
                                "&client_secret=" + OAuthConstants.Secret +
                                "&refresh_token=" + model.RefreshToken,
                                hd => hd.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/x-www-form-urlencoded"),
                                rtnVal =>
                                {
                                    var jsonVal = JsonConvert.DeserializeObject<dynamic>(rtnVal);
                                    vmodel.AccessToken = jsonVal.access_token;
                                    vmodel.RefreshToken = jsonVal.refresh_token;
                                },
                                fault => _logger.LogError("RefreshToken Error: " + fault.ReasonPhrase),
                                ex => _logger.LogError("RefreshToken Error: " + ex)).Wait();
                        }
                        break;
                    case "CallResources":
                        {
                            //访问资源服务
                            var client = new HttpClientHepler(OAuthConstants.ResourceServerBaseAddress + OAuthConstants.ResourcesPath);
                            client.GetAsync(null,
                                    hd => hd.Add("Authorization", "Bearer " + model.AccessToken),
                                    rtnVal => vmodel.Resources = rtnVal,
                                    fault => _logger.LogError("CallResources Error: " + fault.ReasonPhrase),
                                    ex => _logger.LogError("CallResources Error: " + ex)).Wait();

                            vmodel.AccessToken = model.AccessToken;
                            vmodel.RefreshToken = model.RefreshToken;
                        }
                        break;
                    case "Logout":
                        {
                            //注销登陆
                            return Redirect(OAuthConstants.AuthorizationServerBaseAddress + OAuthConstants.LogoutPath + "?"
                                + "logoutId=" + OAuthConstants.Clientid);
                        }
                        break;
                    default:
                        break;
                }
            }
            return View(vmodel);
        }

        public IActionResult AuthCode(AuthCodeModel model)
        {
            GrantClientViewModel vmodel = new GrantClientViewModel();
            if (model.state == OAuthConstants.State)
            {
                //通过code获取AccessToken
                var client = new HttpClientHepler(OAuthConstants.AuthorizationServerBaseAddress + OAuthConstants.TokenPath);
                client.PostAsync(null,
                    "grant_type=" + "authorization_code" +
                    "&code=" + model.code +
                    "&redirect_uri=" + OAuthConstants.AuthorizeCodeCallBackPath +
                    "&client_id=" + OAuthConstants.Clientid +
                    "&client_secret=" + OAuthConstants.Secret,
                    hd => hd.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/x-www-form-urlencoded"),
                    rtnVal =>
                    {
                        var jsonVal = JsonConvert.DeserializeObject<dynamic>(rtnVal);
                        vmodel.AccessToken = jsonVal.access_token;
                        vmodel.RefreshToken = jsonVal.refresh_token;
                    },
                    fault => _logger.LogError("Get AccessToken Error: " + fault.ReasonPhrase),
                    ex => _logger.LogError("Get AccessToken Error: " + ex)).Wait();
            }

            return Redirect("~/Home/Index?" 
                + nameof(vmodel.AccessToken) + "=" + vmodel.AccessToken + "&"
                + nameof(vmodel.RefreshToken) + "=" + vmodel.RefreshToken);
        }

        public IActionResult Error()
        {
            return View();
        }

    }
}
