﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ThirdPartyTest.Models
{
    public class AuthCodeModel
    {
        public string scope { get; set; }
        public string code { get; set; }
        public string state { get; set; }
    }
}
